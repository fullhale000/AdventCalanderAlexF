# HSE-winterbreak-advent-calendar :snowflake:

This is going to be fun!!!
